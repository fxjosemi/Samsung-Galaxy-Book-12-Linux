# Samsung Galaxy Book 12 on Linux

Compatibility fixes for the 2017 Samsung Galaxy Book 12 family. The project is
developed on an SM-W720 and is intended for the Wi-Fi and LTE variants that
share the same board hardware.

Each component has its own hardware checks, installer and removal procedure.
You can install only the fixes you need.

## Install everything

On the supported CachyOS installation, clone the repository and run this once
as your normal user:

```bash
./install.sh all
```

The command requests `sudo` when needed, installs the matching build dependencies,
builds and installs native audio, AMOLED brightness, orientation-sensor and
front/rear-camera drivers, installs the matched libcamera/autofocus package and
the validated Mutter rotation fix, and enables automatic rebuilding after
future kernel updates. Reboot only when it finishes successfully.

Keep a second kernel family such as `linux-cachyos-lts` installed. The automatic
integration only follows the kernel family that was active during installation,
so the second kernel remains an unmodified recovery option. See
[updates/README.md](updates/README.md) for operation and recovery details.

## Supported Linux platform

This repository targets **CachyOS only**. The complete set of fixes is
developed and validated on the project SM-W720 with:

- CachyOS rolling, x86-64-v3;
- Linux `7.1.6-1-cachyos` with the matching CachyOS headers;
- GNOME/Mutter `50.4`;
- libcamera `0.7.2`; and
- PipeWire `1.6.8`.

The external kernel modules are rebuilt automatically for the selected CachyOS
kernel family when its kernel and headers are updated. The patched libcamera,
Mutter and OBS components follow the Arch/CachyOS packaging layout. Other
distributions, including Ubuntu, are not currently supported and may require
source, packaging and installer changes.

## Current fixes

### ALC298 audio

The native Realtek driver patch provides:

- working internal speakers;
- automatic switching between speakers and the 3.5 mm jack;
- separate speaker and headphone DAC paths;
- working stereo separation and volume control;
- correct routing after suspend and resume.

It matches codec `10ec:0298` with Samsung subsystem `144d:c14f`, rather than a
regional model suffix. A short click when inserting the jack remains as a known
hardware limitation.

Installation:

```bash
./kernel/build-module.sh
sudo ./kernel/install-native.sh \
  "kernel/build/$(uname -r)/snd-hda-codec-alc269.ko"
sudo reboot
```

See [INSTALL.md](INSTALL.md) for dependencies and kernel-update instructions.
The older speaker-only userspace fallback remains available through
`sudo ./install.sh`.

### AMOLED brightness

Linux exposes a brightness slider on this machine but does not program the
panel's private AMOLED controls. The brightness component follows the standard
`intel_backlight` slider and sends the corresponding calibrated values over the
internal eDP AUX channel.

It verifies the Galaxy Book 12 DMI identity, the internal eDP connector and the
Samsung Display `SDC a029` EDID before allowing any panel write. By default the
full Linux slider is mapped to panel levels 10–101 with a short fade between
levels. The minimum was tested on the development SM-W720; the original
reverse-engineering work warned that some panels may flicker below 40.

Build and perform the read-only check:

```bash
make -C brightness
./brightness/galaxybook12-brightness check
```

Install the service:

```bash
sudo ./brightness/install.sh
```

The equivalent top-level command is `sudo ./install.sh brightness`.

A native `i915` implementation is also included. It reads the same factory
calibration inside the driver, exposes levels 10–101 directly and does not use
a service or fade. It has been tested on the development SM-W720 with Linux
7.1.6:

```bash
./brightness/kernel/build-module.sh
sudo ./brightness/kernel/install-native.sh \
  "brightness/kernel/build/$(uname -r)/i915.ko"
sudo reboot
```

Keep another kernel installed while testing the native graphics module. Its
installer preserves the distribution driver and provides a rollback script.

More details and manual testing commands are in
[brightness/README.md](brightness/README.md).

### Accelerometer and screen rotation

Samsung exposes the internal K2HH accelerometer as ACPI device `SAM0201`, but
the standard ST accelerometer driver does not match that ID. The sensor patch
binds it to the compatible LIS2HH12 implementation and reads the `ROTM` mount
matrix provided by the firmware. GNOME then receives all four orientations
through the normal IIO and `iio-sensor-proxy` interfaces.

Build and install the two small IIO modules:

```bash
./sensors/kernel/build-module.sh
sudo ./sensors/kernel/install.sh \
  "sensors/kernel/build/$(uname -r)"
sudo reboot
```

The complete implementation has been tested across a cold boot on the
development SM-W720 with Linux 7.1.6 and GNOME/Mutter 50.4: the panel follows
rotation and the firmware axis mapping is correct.  Mutter 50.4 also needs an
upstream session-start fix on this device; a reproducible native Arch/CachyOS
package is included.  See [sensors/README.md](sensors/README.md) for diagnosis,
installation and removal instructions.

### Cameras

The tablet has Intel IPU3, a rear Sony IMX258 (`SONY258A`) and a front Sony
IMX241 (`INT347F`). The rear sensor needs a 26 MHz clock table and a DW9806B
autofocus driver. Both sensors need IPU bridge entries and Samsung-specific
power/reset handling. The project now includes a dedicated native V4L2 IMX241
driver reconstructed from the official Samsung mode and platform data.
The included camera stack provides:

- native IPU3 media-graph detection for both front and rear cameras;
- front-camera RAW10 modes at `2592x1944` and `1296x972`;
- reliable rear-camera detection after a cold boot;
- bounded contrast autofocus that stops at the best measured position;
- validated 16:9 and 4:3 video modes from `160x120` through `4160x3104`, with `1280x720`
  as the default; and
- safe PipeWire/WebRTC negotiation for Firefox and other portal clients.

Build and install the native, reversible five-module kernel override:

```bash
./cameras/kernel/build-module.sh
sudo ./cameras/kernel/install.sh \
  "cameras/kernel/build/$(uname -r)/imx258.ko"
sudo reboot
```

Then build and install the matched `libcamera` and signed IPA packages. They
contain the autofocus, resolution and WebRTC fixes and must be installed
together:

```bash
cd cameras/libcamera
makepkg --cleanbuild --noconfirm
sudo pacman -U ./libcamera-0.7.2-3.9-x86_64.pkg.tar.zst \
  ./libcamera-ipa-0.7.2-3.9-x86_64.pkg.tar.zst
systemctl --user restart wireplumber
```

No second reboot is required for the userspace packages. Firefox must have
`media.webrtc.camera.allow-pipewire` set to `true`; websites choose their own
capture resolution, and the GNOME Camera application may not display a manual
resolution selector even though the modes are exposed.

OBS Studio 32.2.1 needs two additional PipeWire fixes to consume the discrete
resolution list and contiguous IPU3 NV12 buffers without green frames or a
crash. The patched module has been validated at `3840x2160` and 30 FPS. Build
and installation instructions are in [cameras/obs/README.md](cameras/obs/README.md).

The front driver is project-native rather than upstream, and becomes active on
the same reboot as the kernel override. See
[cameras/README.md](cameras/README.md) for the verified hardware findings,
dependencies, status checks and rollback instructions.

## Supported family

The fixes are expected to cover the SM-W720 Wi-Fi and SM-W727 LTE families,
including regional and carrier suffixes, as long as the component-specific
hardware IDs match. Installers stop instead of forcing a fix onto unknown
hardware.

## How the audio fix works

The firmware leaves two internal amplifiers uninitialized and describes shared
output pin `0x17` only as a fixed speaker. The patch initializes both
amplifiers, uses mic pin `0x18` as the reliable jack detector and switches the
shared output between:

```text
Speakers:    DAC 0x02 -> mixer 0x0c -> pin 0x17
Headphones:  DAC 0x03 -> mixer 0x0d -> pin 0x17
```

The audio and display register research is based on Aurélien Croc's GPL-2.0
[Windows/QEMU trace work](https://github.com/Teetoow/SamsungGalaxyBook12).

## Contributing

Reports from other SM-W720 and SM-W727 variants are welcome. Include the exact
model, distribution, kernel version and the hardware IDs relevant to the
component being tested. Do not bypass the safety checks on unrelated hardware.

The project is licensed under GPL-2.0-only. See [LICENSE](LICENSE).
