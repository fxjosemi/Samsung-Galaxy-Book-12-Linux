# Hardware validation checklist

## Driver and hardware

```bash
modinfo -n snd_hda_codec_alc269
cat /sys/class/sound/hwC*D*/vendor_id
cat /sys/class/sound/hwC*D*/subsystem_id
```

The module path should contain `updates/alc298-book12`. Expected codec IDs are
`0x10ec0298` and `0x144dc14f`.

## Cold boot

After a full shutdown and power-on, run:

```bash
speaker-test -D plughw:0,0 -c 2 -t wav -l 1
```

Check left and right channels independently at low volume.

## Headphone jack

Connect the jack with playback stopped, then test left and right channels.
Verify that volume changes work and that unplugging returns playback to the
internal speakers. A short click at insertion is a known limitation.

## Suspend and resume

Suspend once, resume, and repeat both output tests. The codec initialization
and current route should be restored by the native driver.

## Kernel log

```bash
journalctl -k -b | grep -E 'ALC298|144d:c14f|snd_hda_codec_alc269'
```

Include this output, the exact model code and `uname -r` in bug reports.

## Userspace fallback

For the speaker-only fallback, use `./status.sh` after cold boot and resume.
Do not automate its `headphones` action; only the native driver prepares the
dedicated headphone DAC and mixer.

## Orientation sensor

After installing the sensor modules and rebooting, check:

```bash
modinfo -n st_accel
modinfo -n st_accel_i2c
cat /sys/bus/iio/devices/iio:device*/name
cat /sys/bus/iio/devices/iio:device*/mount_matrix
systemctl is-active iio-sensor-proxy
monitor-sensor
```

Both module paths should contain `updates/galaxybook12-sensor`, the device name
should be `lis2hh12`, and `monitor-sensor` should report all four orientations.
With rotation unlocked, verify portrait and both landscape directions in a
Wayland session. Repeat after suspend/resume and a cold boot.  If the sensor
works but GNOME does not rotate after login, verify the compositor claim with:

```bash
busctl get-property net.hadess.SensorProxy \
  /net/hadess/SensorProxy net.hadess.SensorProxy AccelerometerOrientation
busctl --user get-property org.gnome.Mutter.DisplayConfig \
  /org/gnome/Mutter/DisplayConfig \
  org.gnome.Mutter.DisplayConfig PanelOrientationManaged
```

The orientation must not be `undefined`, and panel orientation management must
be enabled in tablet mode.  GNOME/Mutter 50.4 may require the native patch in
`sensors/mutter/` for this state to survive a fresh login.
