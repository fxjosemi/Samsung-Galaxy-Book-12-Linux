import ctypes as c, pathlib, struct
k=c.WinDLL('kernel32',use_last_error=True)
k.EnumSystemFirmwareTables.argtypes=[c.c_uint32,c.c_void_p,c.c_uint32]
k.GetSystemFirmwareTable.argtypes=[c.c_uint32,c.c_uint32,c.c_void_p,c.c_uint32]
provider=int.from_bytes(b'ACPI','big')
n=k.EnumSystemFirmwareTables(provider,None,0)
b=c.create_string_buffer(n)
assert k.EnumSystemFirmwareTables(provider,b,n)==n
out=pathlib.Path(r'C:\Users\xjosemi\Documents\gb12-acpi-private');out.mkdir(exist_ok=True)
for tid, in struct.iter_unpack('<I',b.raw):
    name=tid.to_bytes(4,'little').decode('ascii')
    if name not in ('DSDT','SSDT','FACP'): continue
    size=k.GetSystemFirmwareTable(provider,tid,None,0)
    data=c.create_string_buffer(size)
    assert k.GetSystemFirmwareTable(provider,tid,data,size)==size
    (out/(name+'.dat')).write_bytes(data.raw)
    print(name,size)
