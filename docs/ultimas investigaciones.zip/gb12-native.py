import sys,re
sys.path.insert(0,r'C:\Users\xjosemi\Documents\gb12-research-tools')
import pefile,capstone
p=pefile.PE(sys.argv[1]); base=p.OPTIONAL_HEADER.ImageBase
cs=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64)
pat=sys.argv[2]
for e in p.DIRECTORY_ENTRY_EXCEPTION:
    start=e.struct.BeginAddress; end=e.struct.EndAddress
    ins=list(cs.disasm(p.get_data(start,end-start),base+start))
    if any(re.search(pat,x.op_str) for x in ins) or pat==hex(start):
        print('FUNCTION',hex(start),hex(end))
        for x in ins: print(hex(x.address-base),x.mnemonic,x.op_str)
