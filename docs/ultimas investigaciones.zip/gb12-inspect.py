import sys, re
sys.path.insert(0, r'C:\Users\xjosemi\Documents\gb12-research-tools')
import dnfile, capstone
p=dnfile.dnPE(sys.argv[1])
pattern=sys.argv[2] if len(sys.argv)>2 else 'Performance|Priority|Sabi|SABI'
for i,m in enumerate(p.net.mdtables.MethodDef.rows,1):
    if re.search(pattern,str(m.Name)):
        print(hex(0x06000000+i),hex(m.Rva),m.Name)
        if m.Rva and len(sys.argv)>3:
            if m.ImplFlags.miNative:
                dis=capstone.Cs(capstone.CS_ARCH_X86,capstone.CS_MODE_64)
                for ins in dis.disasm(p.get_data(m.Rva,700),p.OPTIONAL_HEADER.ImageBase+m.Rva):
                    print(hex(ins.address),ins.mnemonic,ins.op_str)
                    if ins.mnemonic=='ret': break
            else:
                from dncil.cil.body.reader import read_method_body_from_bytes
                b=read_method_body_from_bytes(p.get_data(m.Rva,16000))
                for ins in b.instructions:
                    extra=''
                    if hasattr(ins.operand,'value'):
                        t=ins.operand.value
                        tab={6:'MethodDef',4:'Field',10:'MemberRef'}.get(t>>24)
                        if tab: extra=str(getattr(p.net.mdtables,tab).rows[(t&0xffffff)-1].Name)
                    print(ins,extra)
